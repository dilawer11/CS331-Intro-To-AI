1- First, open the directory 'pacman', then the directory 'search' and 
launch the notebook inside it called "Pacman.ipynb" using Jupyter.
That notebook will walk you through the pacman part of this assignment.

2- Once you are done with 'pacman', open the directory 'robot' , read 
README.txt, and launch the notebook called genetic_algorithm.ipynb. That
notebook will walk you through the robot part of this assignment. This 
part is about 'genetic algorithms' specifically. 

Good Luck!