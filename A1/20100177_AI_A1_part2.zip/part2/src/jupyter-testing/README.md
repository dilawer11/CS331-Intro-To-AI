# jupyter-testing

Simple nose-like testing framework for testing within Jupyter Notebooks.
