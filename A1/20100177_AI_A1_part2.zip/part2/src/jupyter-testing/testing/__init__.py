import testing.testing as testing # Compatibility
from .testing import TestImpl

test = TestImpl()
